//Global area
var board = document.getElementsByClassName("col");

window.onload=function() {
//Try and use classname to get a group of divs instead of getting them one by one by id
for(var i = 0; i < board.length; i++){
    board[i].addEventListener("click",function(){
        userTurn(this);
    })
}

}

//if you are writing the same type of code multiple times, you are doing it incorrect

//Attach events using eventlistener here


/************** Function area *******************/

//function provided. Add parameter(s) if needed
function userTurn(box){
    
    box.innerText = "X";
    computerTurn();

}

//function provided. Add parameter(s) if needed
function computerTurn()
{
    for(var i =0; i<board.length; i++){
    
        if(board[i].innerText==""){
            board[i].innerText = "O";
            break;
        }

    }

}