
window.onload = function(){
    var btnOrg =  document.getElementsByClassName("btnOrig");
    for(var i = 0; i < btnOrg.length; i++){
        btnOrg[i].addEventListener("click",function(){
            ChangeButtonText(this);
        })
    }

    var sq1 =  document.getElementsByClassName("square3");
for(var i = 0; i < sq1.length; i++){
    sq1[i].addEventListener("click",function()
    {
        ChangeSquare(this);
    })
}
}
//  Challange 1
function ChangeButtonText(btnOrg){

    btnOrg.innerHTML = "Active";
}

// Challange 2

function ChangeSquare(sq1){

    sq1.style.backgroundColor = "green";
}