 

    //all of jquery your code goes here
    $(document).ready(function(){
        $("#btn1").click(function(){
            $("#1").hide();
            $("#2").hide();
            $("#3").hide();
            $("#4").hide();
        });
        $("#btn2").click(function(){
            $("#1").show();
            $("#2").show();
            $("#3").show();
            $("#4").show();
        });
        $("#btn3").click(function(){
            $("#1").html("one");
            $("#2").html("two");
            $("#3").html("three");
            $("#4").html("four");

            $("#1").css('background-color', 'black');
            $("#2").css('background-color', 'white');
            $("#3").css('background-color', 'black');
            $("#4").css('background-color', 'white');
            $("#1").css('color', 'white');
		    $("#2").css('color', 'black');
		    $("#3").css('color', 'white');
            $("#4").css('color', 'black');
        });

        $("#wrapper").hover(function(){
            $(".wrapperDiv").removeAttr("style");
            $("#1").html("1");
		    $("#2").html("2");
		    $("#3").html("3");
		    $("#4").html("4");
        });
        $("#1").mouseover(function(){
            $("#1").css('background-color', 'yellow');
        });
        $("#2").mouseover(function(){
            $("#2").css('background-color', 'yellow');
        });
        $("#3").mouseover(function(){
            $("#3").css('background-color', 'yellow');
        });
        $("#4").mouseover(function(){
            $("#4").css('background-color', 'yellow');
        });

    })