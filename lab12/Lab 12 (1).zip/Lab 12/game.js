$(function(){
	var containerSize = $("#container").width();
	var boxSize = $("#box").width();
	var move = containerSize - boxSize; 

	$("#up").click(function(){
		$("#box").stop();
		var pos = $("#box").position();
		move = pos.top;
		$("#box").animate({ 
			"top": "-="+move+"px"}, 3000);	
	});

	$("#down").click(function(){
		$("#box").stop();
		var pos = $("#box").position();
		move = containerSize - boxSize - pos.top;
		$("#box").animate({
			 "top": "+="+move+"px" }, 3000);
	});

	$("#left").click(function(){
		$("#box").stop();
		var pos = $("#box").position();
		move = pos.left;
		$("#box").animate({ 
			"left": "-="+move+"px" }, 3000);
	});

	$("#right").click(function(){
		$("#box").stop();
		var pos = $("#box").position();
		move = containerSize - boxSize - pos.left;
		$("#box").animate({ 
				"left": "+="+move+"px" }, 3000);
	});
	$("#fadeout").click(function(){
		$("#box").stop();
		$("#box").fadeOut();
	});
	$("#fadein").click(function(){
		$("#box").stop();
		$("#box").fadeIn();
	});
	$("#blink").click(function(){
		$("#box").fadeOut(1000).fadeIn(1000);
	});
	$("#reset").click(function(){
		$("#box").stop(true).css({top: 0, left: 0});
        $("#box").show();
	});
});