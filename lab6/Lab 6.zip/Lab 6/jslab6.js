function createLink(){
    var a = document.getElementById("parentLink");
    var parent = document.createElement('a');
    var link = document.createTextNode("Click Here ")
    parent.appendChild(link);
    parent.href = "http://www.tri-c.edu";
    a.appendChild(parent);
}

function removeLink(){
    var parent = document.getElementById("parentLink");
    var child = parent.lastElementChild;
    parent.removeChild(child);
}

function changeColor(){
    var box=document.getElementById("box");
    var colorName=document.getElementById("inputColor").value;
    box.style.backgroundColor=colorName;
}

function changeSquares(){
    var squares1=document.getElementsByClassName("square1");
    var squares2=document.getElementsByClassName("square2");

    for(var i=0;i<squares1.length;i++){
        if(squares1[i].style.backgroundColor=="lightgreen"){
            squares1[i].style.backgroundColor="black";
            squares1[i].style.color = "yellow";
        }
        else if(squares1[i].style.backgroundColor=="black"){
            squares1[i].style.backgroundColor="white";
            squares1[i].style.color = "black";
        }
        else{
            squares1[i].style.backgroundColor="black";
            squares1[i].style.color = "yellow";
        }
        if(squares2[i].style.backgroundColor=="lightgreen"){ 
            squares2[i].style.backgroundColor="white";
            squares2[i].style.color = "black";
        }
        else if(squares2[i].style.backgroundColor=="white"){
            squares2[i].style.backgroundColor="black";
            squares2[i].style.color = "yellow";
        }
        else{
            squares2[i].style.backgroundColor="white";
            squares2[i].style.color = "black";
        }
    }
}

function changeShape(){
    var radius=document.getElementById("inputRadius").value;
    var squares1=document.getElementsByClassName("square1");
    for(var i=0;i<squares1.length;i++){
        squares1[i].style.borderRadius=radius;
    }
}